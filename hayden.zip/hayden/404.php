<?php get_header(); ?>
	
		<div id="pageHead">
			<h1><?php _e('Page Not Found', 'themetrust'); ?></h1>
		</div>
							 
		<div id="content" class="twoThirds clearfix">
			<p><?php _e("Sorry, but what you're looking for could not be found.", 'themetrust'); ?></p> 
		</div>
			
<?php get_footer(); ?>